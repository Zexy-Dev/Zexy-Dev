**What is this?**

Credit to the Author - Zerofour04

This is the Standered esx_policejob but iv Heavy Worked on it To Make it Better

**Installation**
**1 - Clone this repository 2 - Install this resource to your [esx] directory 3 - Add start esx_policejob in your server.cfg or resources.cfg 4 - And you're done!**
**2 - Run Your Server**
