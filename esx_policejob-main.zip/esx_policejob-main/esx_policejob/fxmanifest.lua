fx_version 'adamant'
game 'gta5'
author 'Oringal Author: Zerofour04 Edited By: 𝚊𝚗𝚍𝚛𝚎𝚠#8888'
description 'esx_policejob Heavily Edited'
version '1.0.0'

dependency 'essentialmode'
dependency 'mysql-async'
dependency 'es_extended'

client_scripts {
	'@es_extended/locale.lua',
	"client/*",
	"locales/*",
	"configs/config.lua",
}

server_scripts {
	'@es_extended/locale.lua',
	'@mysql-async/lib/MySQL.lua',
	"locales/*",
	"server/*",
	"configs/config.lua",
}